@extends('default.layout.layout')

@section('content')
<section class="wrapper site-min-height">
  <div class="row mt">
    <div class="col-lg-12">
      <div class="row content-panel">
        <h2 class='violet'>Control Panel</h2>
        <hr/>
        <div class="col-md-4">
          <h4 class=''>Backup Manager</h4>
            <a href="{{route('site.backup')}}" class="btn btn-lg btn-theme">Create Backup</a>
            <a href="{{route('site.download')}}" class="btn btn-lg btn-theme">Download Backup</a>
        </div>

      </div><!-- /row -->    
    </div><! --/col-lg-12 -->
  </div><! --/container -->
</section><! --/wrapper -->
@stop

@section('script')
@stop

