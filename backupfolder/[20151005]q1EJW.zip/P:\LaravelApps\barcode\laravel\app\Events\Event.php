<?php

namespace bepc\Events;

abstract class Event
{
    //
}
